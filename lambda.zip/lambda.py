def lambda_handler(event, context):
            return "Hello World!"














# import pandas as pd

# def lambda_handler(event, context):
#     d = {'col1': [1,2], 'col2': [3,6]}
#     df = pd.DataFrame(data=d)
#     print(df)
#     print('Done 2nd version')